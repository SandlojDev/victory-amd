Location for Folder: C:\Users\User_Name\AppData\Local\victory

Contains: (Size: 545 KB (558,111 bytes))

Folder: victory\data\7952987A\saves\0009000000000001\00000000-0000-0000-0000-00007952987a\Player~333dc56ddffd8ea0\v5
Files:	0
	1
	manifest

Folder: victory\data\7952987A\saves\0009000000000001\00000000-0000-0000-0000-00007952987a\SARC0000~f3a9b4e1a0576c96\v1
Files:	0
	1
	manifest

Folder: victory\data\7952987A\saves\0009000000000001\00000000-0000-0000-0000-00007952987a\SARC0015~f3ad35e1a05a7da0\v3
Files:	0
	1
	manifest

Folder: victory\data\7952987A\saves\0009000000000001\00000000-0000-0000-0000-00007952987a\SettingsProfileSettings~0b4e25fca06268d0\v1
Files:	0
	1
	manifest

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Folder: victory\data\7952987A\storage\cloudcache
Files:	N/A

Folder: victory\data\7952987A\storage\cloudpers
Files:	N/A

Folder: victory\data\7952987A\storage\settings
Files:	settings.xml